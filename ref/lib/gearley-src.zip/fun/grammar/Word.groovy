package fun.grammar


public class Word {
    public String tag

    Word(String tag) {
        this.tag = tag
    }

    @Override
    String toString() { tag }
}
