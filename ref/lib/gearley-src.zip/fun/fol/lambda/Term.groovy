package fun.fol.lambda

interface Term {

    Set<Variable> getFreeVariables()
}
