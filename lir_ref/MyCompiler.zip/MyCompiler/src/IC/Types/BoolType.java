package IC.Types;

/**
 * The type of booleans in the program
 * 
 * @author Asaf Bruner, Aviv Goll
 */
public class BoolType extends Type {

	public BoolType() {
		super("boolean");
		// TODO Auto-generated constructor stub
	}

}
